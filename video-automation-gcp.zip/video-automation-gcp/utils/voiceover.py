import os
import tempfile
from google.cloud import texttospeech

MAX_WORDS = 4500

def split_script(script):
    words = script.split()
    for i in range(0, len(words), MAX_WORDS):
        yield " ".join(words[i:i+MAX_WORDS])

def generate_voiceover(script):
    client = texttospeech.TextToSpeechClient()
    chunks = list(split_script(script))
    audio_files = []

    for i, chunk in enumerate(chunks):
        synthesis_input = texttospeech.SynthesisInput(text=chunk)
        voice = texttospeech.VoiceSelectionParams(language_code="en-US", name="en-US-Studio-O")
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

        response = client.synthesize_speech(input=synthesis_input, voice=voice, audio_config=audio_config)

        audio_path = tempfile.mktemp(suffix=".mp3")
        with open(audio_path, "wb") as out:
            out.write(response.audio_content)
        audio_files.append(audio_path)

    final_audio = tempfile.mktemp(suffix=".mp3")
    os.system(f"ffmpeg -y -i \"concat:{'|'.join(audio_files)}\" -c copy {final_audio}")
    return final_audio

