import vertexai
from vertexai.preview.vision_models import ImageGenerationModel
import os
import tempfile

def generate_images(script):
    vertexai.init(project=os.getenv("GOOGLE_CLOUD_PROJECT"), location="us-central1")
    model = ImageGenerationModel.from_pretrained("imagegeneration@002")

    prompts = [
        "Beautiful cinematic scene related to: " + script[:100],
        "Another cinematic illustration from the same theme",
        "Epic wide shot landscape related to: " + script[:100]
    ]

    images = []
    for prompt in prompts:
        img = model.generate_images(prompt=prompt, number_of_images=1, aspect_ratio="16:9")[0]
        img_path = tempfile.mktemp(suffix=".jpg")
        img.save(img_path)
        images.append(img_path)
    return images

