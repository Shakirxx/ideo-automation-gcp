import pysrt
import tempfile

def generate_captions(script, audio_file):
    subs = pysrt.SubRipFile()
    subs.append(pysrt.SubRipItem(1, start="00:00:00,000", end="00:00:05,000", text=script))
    captions_file = tempfile.mktemp(suffix=".srt")
    subs.save(captions_file)
    return captions_file

