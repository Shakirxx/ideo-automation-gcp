from moviepy.editor import *
import os

def render_video(images, audio_file, captions_file):
    clips = []
    for img in images:
        img_clip = ImageClip(img).set_duration(5).fadein(1).fadeout(1)
        clips.append(img_clip)

    final_clip = concatenate_videoclips(clips, method="compose").set_audio(AudioFileClip(audio_file))
    output_path = "static/output/final.mp4"
    os.makedirs("static/output", exist_ok=True)
    final_clip.write_videofile(output_path, fps=24)
    return output_path

